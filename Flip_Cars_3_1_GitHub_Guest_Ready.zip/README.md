# Flip Cars 3.1 — Guest-Friendly Racing

**Three laps, simultaneous card flips, up to four racers.** A single-file browser game that works on mobile and desktop. Solo and local multiplayer work without accounts or a server. Online private rooms use the included Cloudflare Worker (a separate one-time deployment).

## Play the game

Open `index.html` in a browser. Choose **Start Local Race** for one to four local human drivers plus optional computer racers.

After this repository is published with GitHub Pages, its expected URL is:

https://jrami1122-lab.github.io/Flip-cars/

*The URL is not confirmed live until GitHub Pages is enabled and deployed.*

## Give guests the easiest possible experience

Once the site and online Worker are deployed:

1. Host opens the game and chooses **Race with friends → Host a race**.
2. Host selects **Share Invite** or **Copy Link** in the race garage, and sends the link by message.
3. Guest taps the link, enters a nickname, and taps **Join Race**. **No sign-up, password, downloads, or server URL required for invited guests.**
4. Host sees connected racers, optionally adds CPU cars, and taps **Start the Race**.
5. If someone disconnects, they can use **Rejoin My Previous Seat** or the reconnect button. Rooms expire after inactivity; a new invite is needed if the old room is no longer available.

The invite includes the room code and, when necessary, a server address so a guest does not have to configure the multiplayer backend. Do not publish room links publicly if you want to keep races private. Invite codes are not passwords.

**Important:** Without the Cloudflare Worker running, the host cannot create online rooms and guests cannot join. This HTML file does not include a hosted online server.

## Install on your existing GitHub repository

Your repository is: https://github.com/jrami1122-lab/Flip-cars

A ChatGPT GitHub connector attempt returned HTTP **403 Resource not accessible by integration**, so this ZIP is **not** already uploaded to GitHub.

1. Extract the archive.
2. In the repository, choose **Add file → Upload files**. Upload `index.html` and `.nojekyll` to the top-level repository. You may also upload this README, `worker/`, and `tests/` for keeping the full source in GitHub.
3. Commit to the `main` branch.
4. Go to **Settings → Pages** → **Build and deployment**. Choose **Deploy from a branch**, select `main`, select `/(root)`, then **Save**.
5. Wait for the first deployment and open the Pages URL above. Verify solo play first.

No JavaScript dependencies, build scripts, install, or CDN needed for the browser-only game.

## Enable online multiplayer (host's one-time task)

This repository includes a server-authoritative Cloudflare Worker in `worker/`, using WebSockets and Durable Objects. It does **not** deploy itself and may require a Cloudflare plan supporting Durable Objects.

With a Cloudflare account and Node.js installed, run:

```bash
cd worker
npm install
npx wrangler login
npm run deploy
```

When deployment finishes, open `<worker-url>/api/health` to verify the service. It should return a JSON object containing `"ok":true`.

To make the server automatically available to **all hosts**, open `index.html` and set:

```js
const DEFAULT_SERVER_URL = 'https://YOUR-DEPLOYED-WORKER.workers.dev';
```

Then upload the edited `index.html` to GitHub again. If this value is blank, the host can enter the Worker URL in **Host setup** once; their share links automatically include the server so guests won't need to know it. Do not enter placeholder/example URLs as though they're deployed.

GitHub Pages hosts the browser game, **not** the online room service; Cloudflare hosts the latter. No persistent player accounts are required. Rooms are temporary and are not publicly indexed.

## Main features

- Up to four human racers locally or online; optional CPU opponents.
- Three-lap winding circuit with alternative routes, shortcuts, riskier paths, flag cards, speed boosts, collisions and pit stops.
- Identical weighted decks for each player: eight 1s, seven 2s, five 3s, four 4s, three 5s. Movement cards reveal simultaneously.
- Phone/tablet-friendly touchscreen UI, wide/portrait fit, fullscreen and board-focused solo view.
- Sound controls, keyboard support, route choices, rules/help screen, reconnect controls.
- Online join-by-invite link; guest nickname instead of account; copy/share actions; 6-character room-code fallback.

## Tests and limits

`node --test tests/*.test.mjs` — **six tests passed** during preparation. Browser smoke checks were also performed for offline/desktop, mobile, invite entry and a **mocked** online host lobby. This does not establish that GitHub Pages or a live Cloudflare Worker has been deployed; a full public end-to-end multiplayer test is still required.

## Files

- `index.html` — complete browser game and GitHub Pages landing page.
- `.nojekyll` — prevents unwanted Jekyll processing.
- `worker/src/index.js` — room service and synchronized game logic.
- `worker/wrangler.toml` — Cloudflare Worker settings.
- `worker/package.json` — Worker deployment script.
- `tests/game.test.mjs` and `tests/room.test.mjs` — Node automated tests.
- `README.md` — these instructions.
